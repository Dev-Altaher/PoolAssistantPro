package com.cart3r.poolassistant

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddAPhoto
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.*

private val Bg = Color(0xFF080808)
private val Panel = Color(0xFF171111)
private val Red = Color(0xFFFF3434)
private val Muted = Color(0xFFB8A6A6)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { PoolAssistantApp() }
    }
}

private enum class Screen { TRAINER, IMAGE }

@Composable
fun PoolAssistantApp() {
    var screen by remember { mutableStateOf(Screen.TRAINER) }
    var bitmap by remember { mutableStateOf<Bitmap?>(null) }
    var cue by remember { mutableStateOf<Offset?>(null) }
    var objectBall by remember { mutableStateOf<Offset?>(null) }
    var target by remember { mutableStateOf(Offset(0.78f, 0.25f)) }
    var dragStart by remember { mutableStateOf<Offset?>(Offset(0.22f, 0.52f)) }
    var dragEnd by remember { mutableStateOf(Offset(0.75f, 0.5f)) }
    var imageTapStage by remember { mutableIntStateOf(0) }
    val context = LocalContext.current

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        if (uri != null) {
            bitmap = runCatching {
                context.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it) }
            }.getOrNull()
            cue = null
            objectBall = null
            imageTapStage = 0
        }
    }

    MaterialTheme(colorScheme = darkColorScheme(
        primary = Red, background = Bg, surface = Panel,
        onPrimary = Color.White, onBackground = Color.White, onSurface = Color.White
    )) {
        Column(
            Modifier.fillMaxSize().background(Bg).verticalScroll(rememberScrollState()).padding(16.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()) {
                Column {
                    Text("POOL ASSISTANT", color = Red, fontSize = 22.sp, fontWeight = FontWeight.Black)
                    Text("PRO  •  TRAINING & SHOT ANALYSIS", color = Muted, fontSize = 10.sp)
                }
                Surface(color = Color(0xFF321010), shape = RoundedCornerShape(50)) {
                    Text("OFFLINE", color = Red, modifier = Modifier.padding(horizontal = 12.dp, vertical = 7.dp), fontSize = 11.sp)
                }
            }
            Spacer(Modifier.height(18.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                ModeButton("AIM TRAINER", screen == Screen.TRAINER, Modifier.weight(1f)) { screen = Screen.TRAINER }
                ModeButton("IMAGE ANALYZER", screen == Screen.IMAGE, Modifier.weight(1f)) { screen = Screen.IMAGE }
            }
            Spacer(Modifier.height(16.dp))

            if (screen == Screen.TRAINER) {
                SectionTitle("INTERACTIVE AIM TRAINER")
                Text("اسحب من الكرة البيضاء لتحديد اتجاه التسديدة. هذا تدريب ومحاكاة مستقل.", color = Muted, fontSize = 12.sp)
                Spacer(Modifier.height(10.dp))
                PoolBoard(
                    cue = Offset(0.22f, 0.52f),
                    objectBall = Offset(0.58f, 0.42f),
                    target = target,
                    onTargetChange = { target = it },
                    dragStart = dragStart,
                    dragEnd = dragEnd,
                    onAimChange = { a, b -> dragStart = a; dragEnd = b }
                )
                Spacer(Modifier.height(12.dp))
                val angle = atan2(dragEnd.y - dragStart!!.y, dragEnd.x - dragStart!!.x) * 180 / PI
                InfoPanel("AIM ANGLE", "${"%.1f".format(angle)}°")
                Text("حرّك نقطة الهدف على الطاولة، ثم اسحب لتجربة زاوية التصويب.", color = Muted, fontSize = 12.sp)
                OutlinedButton(onClick = {
                    dragStart = Offset(0.22f, 0.52f)
                    dragEnd = Offset(0.75f, 0.5f)
                    target = Offset(0.78f, 0.25f)
                }, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.outlinedButtonColors(contentColor = Red)) {
                    Icon(Icons.Default.Refresh, null); Spacer(Modifier.width(8.dp)); Text("إعادة ضبط التدريب")
                }
            } else {
                SectionTitle("SCREENSHOT ANALYZER")
                Text("اختر صورة محفوظة للطاولة. حدّد الكرة البيضاء والكرة المراد استهدافها بالنقر على الصورة.", color = Muted, fontSize = 12.sp)
                Spacer(Modifier.height(10.dp))
                Button(onClick = { picker.launch("image/*") }, modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = Red)) {
                    Icon(Icons.Default.AddAPhoto, null); Spacer(Modifier.width(8.dp)); Text("اختيار صورة")
                }
                Spacer(Modifier.height(12.dp))
                if (bitmap != null) {
                    ImageAnalysisBoard(bitmap!!, cue, objectBall, onTap = { p ->
                        if (imageTapStage == 0) { cue = p; objectBall = null; imageTapStage = 1 }
                        else { objectBall = p; imageTapStage = 0 }
                    })
                    Spacer(Modifier.height(8.dp))
                    Text(
                        when {
                            cue == null -> "الخطوة 1: انقر على الكرة البيضاء."
                            objectBall == null -> "الخطوة 2: انقر على الكرة المستهدفة."
                            else -> "تم تحديد الكرتين. الخط الأخضر يوضح خط المركزين التقريبي."
                        }, color = Muted, fontSize = 12.sp
                    )
                    if (cue != null && objectBall != null) {
                        val dx = objectBall!!.x - cue!!.x
                        val dy = objectBall!!.y - cue!!.y
                        InfoPanel("CENTER-LINE ANGLE", "${"%.1f".format(atan2(dy, dx) * 180 / PI)}°")
                    }
                    OutlinedButton(onClick = { cue = null; objectBall = null; imageTapStage = 0 },
                        modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.outlinedButtonColors(contentColor = Red)) {
                        Text("مسح التحديد")
                    }
                } else {
                    Box(Modifier.fillMaxWidth().height(210.dp).background(Panel, RoundedCornerShape(14.dp)),
                        contentAlignment = Alignment.Center) {
                        Text("لم يتم اختيار صورة بعد", color = Muted)
                    }
                }
                Text("ملاحظة: تحديد الكرات يدوي في هذه النسخة؛ لا يوجد تعرّف آلي مضمون على الكرات أو اتصال بلعبة 8 Ball Pool.", color = Muted, fontSize = 11.sp)
            }
            Spacer(Modifier.height(20.dp))
            Divider(color = Color(0xFF512020))
            Spacer(Modifier.height(10.dp))
            Text("CART3R.JAILBREAK  •  POOL ASSISTANT PRO 1.0", color = Muted, fontSize = 10.sp)
        }
    }
}

@Composable
private fun ModeButton(label: String, selected: Boolean, modifier: Modifier, onClick: () -> Unit) {
    Button(onClick = onClick, modifier = modifier.height(46.dp),
        colors = ButtonDefaults.buttonColors(containerColor = if (selected) Red else Panel,
            contentColor = if (selected) Color.White else Muted),
        shape = RoundedCornerShape(10.dp), contentPadding = PaddingValues(4.dp)) {
        Text(label, fontSize = 10.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun SectionTitle(text: String) {
    Text(text, color = Red, fontWeight = FontWeight.Bold, fontSize = 14.sp)
}

@Composable
private fun InfoPanel(label: String, value: String) {
    Row(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(10.dp)).padding(14.dp),
        horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
        Text(label, color = Muted, fontSize = 11.sp)
        Text(value, color = Red, fontWeight = FontWeight.Bold, fontSize = 18.sp)
    }
}

@Composable
private fun PoolBoard(
    cue: Offset, objectBall: Offset, target: Offset, onTargetChange: (Offset) -> Unit,
    dragStart: Offset?, dragEnd: Offset, onAimChange: (Offset, Offset) -> Unit
) {
    var size by remember { mutableStateOf(Size.Zero) }
    Canvas(Modifier.fillMaxWidth().height(270.dp)
        .pointerInput(size) {
            detectTapGestures { p ->
                if (size.width > 0 && size.height > 0) onTargetChange(Offset((p.x / size.width).coerceIn(0f,1f), (p.y / size.height).coerceIn(0f,1f)))
            }
        }
        .pointerInput(size) {
            detectDragGestures(
                onDragStart = { p -> onAimChange(cue, Offset((p.x / size.width).coerceIn(0f,1f), (p.y / size.height).coerceIn(0f,1f))) },
                onDrag = { change, _ ->
                    val p = change.position
                    onAimChange(cue, Offset((p.x / size.width).coerceIn(0f,1f), (p.y / size.height).coerceIn(0f,1f)))
                }
            )
        }) {
        size = this.size
        drawRoundRect(Color(0xFF56301D), size = this.size, cornerRadius = androidx.compose.ui.geometry.CornerRadius(24f))
        drawRoundRect(Color(0xFF12613E), topLeft = Offset(14f,14f),
            size = Size(this.size.width-28f,this.size.height-28f), cornerRadius = androidx.compose.ui.geometry.CornerRadius(18f))
        val w = this.size.width; val h = this.size.height
        val pockets = listOf(Offset(.035f,.055f),Offset(.5f,.055f),Offset(.965f,.055f),Offset(.035f,.945f),Offset(.5f,.945f),Offset(.965f,.945f))
        pockets.forEach { drawCircle(Color.Black, 12f, Offset(it.x*w,it.y*h)) }
        fun pt(o: Offset) = Offset(o.x*w,o.y*h)
        drawCircle(Color.White, 11f, pt(cue))
        drawCircle(Color(0xFFF4C542), 11f, pt(objectBall))
        drawCircle(Red, 5f, pt(target))
        drawCircle(Red, 11f, pt(target), style = Stroke(2f))
        val start = pt(cue)
        val end = pt(dragEnd)
        drawLine(Color(0xFFFFF176), start, end, 3f)
        drawLine(Color(0x8877FFAA), pt(objectBall), pt(target), 2f, pathEffect = null)
    }
}

@Composable
private fun ImageAnalysisBoard(bitmap: Bitmap, cue: Offset?, objectBall: Offset?, onTap: (Offset) -> Unit) {
    var viewSize by remember { mutableStateOf(Size.Zero) }
    BoxWithConstraints(Modifier.fillMaxWidth().height(260.dp).background(Color.Black, RoundedCornerShape(12.dp))) {
        val maxW = constraints.maxWidth.toFloat()
        val maxH = constraints.maxHeight.toFloat()
        Canvas(Modifier.fillMaxSize().pointerInput(bitmap, viewSize) {
            detectTapGestures { p ->
                val scale = min(size.width / bitmap.width, size.height / bitmap.height)
                val shownW = bitmap.width * scale
                val shownH = bitmap.height * scale
                val left = (size.width - shownW) / 2f
                val top = (size.height - shownH) / 2f
                val x = ((p.x - left) / shownW).coerceIn(0f, 1f)
                val y = ((p.y - top) / shownH).coerceIn(0f, 1f)
                onTap(Offset(x, y))
            }
        }) {
            viewSize = size
            val scale = min(size.width / bitmap.width, size.height / bitmap.height)
            val shownW = bitmap.width * scale
            val shownH = bitmap.height * scale
            val left = (size.width - shownW) / 2f
            val top = (size.height - shownH) / 2f
            drawImage(bitmap.asImageBitmap(), dstOffset = IntOffset(left.roundToInt(), top.roundToInt()),
                dstSize = IntSize(shownW.roundToInt(), shownH.roundToInt()))
            fun pt(p: Offset) = Offset(left + p.x * shownW, top + p.y * shownH)
            if (cue != null) drawCircle(Color.Cyan, 12f, pt(cue), style = Stroke(3f))
            if (objectBall != null) {
                drawCircle(Red, 12f, pt(objectBall), style = Stroke(3f))
                if (cue != null) drawLine(Color(0xFF7CFF9B), pt(cue), pt(objectBall), 3f)
            }
        }
    }
}
