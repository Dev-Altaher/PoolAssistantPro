# Pool Assistant Pro

Android Studio project for an offline billiards training helper.

## Features
- Interactive practice table: drag to draw an aim direction and tap to move the target marker.
- Screenshot analyzer: load an image from the gallery and manually mark the cue ball and target ball.
- Displays the approximate center-line angle.
- No account access, game modification, automation, or interaction with 8 Ball Pool.

## Build
1. Install Android Studio (Giraffe or newer) and JDK 17.
2. Open this folder in Android Studio.
3. Allow Gradle sync to finish.
4. Select Build > Build Bundle(s) / APK(s) > Build APK(s).
5. Find the APK under `app/build/outputs/apk/debug/app-debug.apk`.

The screenshot tool uses manual point selection in this starter version; it does not claim automatic ball recognition.
